package com.ctrip.framework.apollo.common.exception;

public class BeanUtilsException extends RuntimeException{

  public BeanUtilsException(Throwable e){
    super(e);
  }

}
