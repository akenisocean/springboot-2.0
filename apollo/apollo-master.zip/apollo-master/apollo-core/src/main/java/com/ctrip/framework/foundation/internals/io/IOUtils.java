package com.ctrip.framework.foundation.internals.io;

public class IOUtils {
  public static final int EOF = -1;
}
